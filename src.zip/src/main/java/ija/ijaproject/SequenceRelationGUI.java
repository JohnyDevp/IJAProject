package ija.ijaproject;

public class SequenceRelationGUI {
}
