package ija.ijaproject;
import ija.ijaproject.Main;

/**
 * class for launching whole app - leads to Main class
 * @author xzimol04*/
public class Launcher {
    public static void main(String[] args){
        Main.main(args);
    }
}
